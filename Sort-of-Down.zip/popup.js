document.getElementById("toggle-details").addEventListener("click", () => {
  const progressBar = document.getElementById("progress-bar");
  progressBar.style.display = progressBar.style.display === "none" ? "block" : "none";
});

chrome.downloads.onChanged.addListener((delta) => {
  if (delta.state && delta.state.current === "in_progress") {
    const progress = (delta.bytesReceived / delta.totalBytes) * 100;
    document.getElementById("progress").style.width = `${progress}%`;
    document.getElementById("status").innerText = `Downloading: ${progress.toFixed(2)}%`;
  }
});
