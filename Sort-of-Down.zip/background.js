// Define file type categories
const fileTypeCategories = {
  "images": [".jpg", ".jpeg", ".png", ".gif", ".bmp", ".svg", ".webp"],
  "documents": [".pdf", ".doc", ".docx", ".txt", ".odt", ".rtf", ".html"],
  "videos": [".mp4", ".mkv", ".avi", ".mov", ".wmv", ".flv"],
  "audio": [".mp3", ".wav", ".aac", ".flac"],
  "archives": [".zip", ".rar", ".7z", ".tar", ".gz"],
  "code": [".js", ".css", ".html", ".py", ".java", ".cpp", ".sh"]
};

// Determine file type from extension
function getFileType(extension) {
  for (const [type, extensions] of Object.entries(fileTypeCategories)) {
    if (extensions.includes(extension.toLowerCase())) {
      return type;
    }
  }
  return "others"; // Default category
}

// Check if a file already exists and generate a unique name
function getUniqueFilename(folder, filename) {
  let suffix = 1;
  const base = filename.replace(/(\.\w+)$/, ""); // Remove extension
  const ext = filename.match(/(\.\w+)$/)[0]; // Extract extension

  while (fileExists(folder, `${base}(${String(suffix).padStart(4, '0')})${ext}`)) {
    suffix++;
  }
  return `${base}(${String(suffix).padStart(4, '0')})${ext}`;
}

function fileExists(folder, filename) {
  // Placeholder: Implement file existence check using appropriate API
  return false;
}

// Match a download item to a rule
function matchesRule(downloadItem, rule, fileType) {
  const fileNameMatches = rule.name && downloadItem.filename.includes(rule.name);
  const fileSizeMatches = rule.size && downloadItem.fileSize >= rule.size.min && downloadItem.fileSize <= rule.size.max;
  const fileTypeMatches = rule.fileType && rule.fileType === fileType;
  const domainMatches = rule.domain && downloadItem.url.includes(rule.domain);

  return fileNameMatches || fileSizeMatches || fileTypeMatches || domainMatches;
}

// Handle download events
chrome.downloads.onDeterminingFilename.addListener((downloadItem, suggest) => {
  chrome.storage.sync.get(["rules"], (data) => {
    const rules = data.rules || [];
    rules.sort((a, b) => a.priority - b.priority);

    const fileExtension = `.${downloadItem.filename.split('.').pop()}`;
    const fileType = getFileType(fileExtension);

    for (let rule of rules) {
      if (matchesRule(downloadItem, rule, fileType)) {
        const targetFolder = rule.folder;
        const newFilename = `${targetFolder}/${getUniqueFilename(targetFolder, downloadItem.filename)}`;
        suggest({ filename: newFilename });
        return;
      }
    }
    suggest(); // Default if no rule matches
  });
});
