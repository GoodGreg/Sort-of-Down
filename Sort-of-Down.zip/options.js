document.getElementById("rules-form").addEventListener("submit", (event) => {
  event.preventDefault();

  const folder = document.getElementById("folder").value;
  const fileType = document.getElementById("fileType").value;
  const priority = parseInt(document.getElementById("priority").value, 10);

  chrome.storage.sync.get(["rules"], (data) => {
    const rules = data.rules || [];
    rules.push({ folder, fileType, priority });
    chrome.storage.sync.set({ rules }, () => {
      alert("Rule saved!");
    });
  });
});
